# Thanatos MCP - Security Research PoC
