# Thanatos MCP - Parasite Layers
